﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ShortnerController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<ShortnerController> _logger;

        public ShortnerController(ILogger<ShortnerController> logger)
        {
            _logger = logger;
        }

        

        [HttpGet("getshortner")]
        public string GetShortnerUrl(string deviceid, string orgurl, long validaitytimestamp, string friendlyurl)
        {
            var result = Shortner.Instance.AddUrl(deviceid, orgurl, validaitytimestamp, friendlyurl);

            return result;
        }
        [HttpGet("getdecoderurl")]
        public string DecodeShortnerUrl(string url)
        {
            var splitstring = url.Split("/");
            var deviceinfo = Shortner.tempstorage[splitstring[0]];
            foreach (var item in deviceinfo)
            {
                if (string.Equals(item.friendlyurl, splitstring[1], StringComparison.OrdinalIgnoreCase))
                {
                    DateTime today = DateTime.Now;
                    long unixTime = ((DateTimeOffset)today).ToUnixTimeSeconds();
                    if (item.Timestamp > unixTime)
                    {
                        return item.Url;
                    }
                }
            }
            return "Invalid / Expired Connection";
        }
    }
}

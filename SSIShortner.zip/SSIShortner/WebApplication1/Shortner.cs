﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace WebApplication1
{
    public class Shortner
    {
        private Shortner()
        { }

        public static Shortner Instance { get { return Shortner.Nested.instance; } }

        public static Dictionary<string, List<Shortner>> tempstorage { get { return Shortner.Nested.tempstorage1; } }
        private class Nested
        {
            // Explicit static constructor to tell C# compiler
            // not to mark type as beforefieldinit
            static Nested()
            { }
            internal static Dictionary<string, List<Shortner>> tempstorage1 = new Dictionary<string, List<Shortner>>();

            internal static readonly Shortner instance = new Shortner();
        }


        public string Url { get; set; }

        public string maskedUrl { get; set; }
        public string friendlyurl { get; set; }

        public long Timestamp { get; set; }

        public static Dictionary<string, List<Shortner>> getStorage()
        {
            return tempstorage;
        }

        public string AddUrl(string deviceid, string orgurl, long validaitytimestamp, string friendlyurl)
        {

            if (checkiffriendlyurlexist(deviceid, friendlyurl))
            {
                return "Friendly URL Exist";
            }

            else
            {
                 List<Shortner> temp = new List<Shortner>();

                if (Shortner.tempstorage.ContainsKey(deviceid))
                {
                    temp = Shortner.tempstorage[deviceid];
                }
                
                var t = string.Empty;
                if (friendlyurl != null)
                {
                    t = friendlyurl;
                }
                else
                {
                    t = ComputeSHA256Hash(Url);
                    friendlyurl = t;
                }
                temp.Add(new Shortner() { Url = orgurl, friendlyurl = friendlyurl, Timestamp = validaitytimestamp, maskedUrl = t });
                Shortner.tempstorage[deviceid] = temp;


            }
            return deviceid + "/" + friendlyurl;
        }

        public bool checkiffriendlyurlexist(string deviceid, string friendlyurl)
        {
            if (friendlyurl == "")
            {
                return false;
            }
            if (Shortner.tempstorage.Count > 0 && tempstorage[deviceid] != null)
            {
                var deviceshort = tempstorage[deviceid];
                foreach (var item in deviceshort)
                {
                    if (item.friendlyurl == friendlyurl)
                    {
                        return true;
                    }
                }

            }
            return false;
        }

        public static string ComputeSHA256Hash(string text)
        {
            using (var sha256 = new SHA256Managed())
            {
                return BitConverter.ToString(sha256.ComputeHash(Encoding.UTF8.GetBytes(text))).Replace("-", "").Substring(0, 10);
            }
        }

    }
}
